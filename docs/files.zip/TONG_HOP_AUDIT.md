# Yana AI — Tổng hợp Audit & Fix (2026-07-01)

Tài liệu duy nhất gộp lại toàn bộ 2 vòng audit + 2 vòng fix. Đọc file này là đủ,
không cần lục lại cả đoạn chat.

**2 file đã giao, áp theo đúng thứ tự này:**
1. `Yana-AI-fixes.zip` — vòng 1 (18 file — số liệu, security, build)
2. `Yana-AI-fixes-round2.zip` — vòng 2 (8 file — bug logic thật trong Rust/bash/JS)

Cả 2 độc lập nhau về code (không đè lên nhau), nhưng áp theo thứ tự thời gian
cho dễ theo dõi qua `git log`.

---

## 1. Vòng 1 — Audit số liệu, security, version, build

### Đã fix (Yana-AI-fixes.zip)

| Vấn đề | File | Verify |
|---|---|---|
| API key hardcode trong `chat-qwen.js` | *(đã tự sửa từ trước khi mình vào, xác nhận lại)* | file đã bị xoá, thay bằng `adapters/qwen.md` |
| `.claude/config/skills-lock.json`: 8557 entry claim, chỉ 395 (4.6%) thật | file này | prune còn 414, verify 100% resolve |
| `core/config/skills-lock.json`: 88 entry chết + 1 entry sai schema (`vuln-chain`) | file này | prune bằng chính script có sẵn `verify-skills-lock.sh --prune` |
| `findBestSkill` chỉ match tên thư mục, bỏ qua `description` | `tools/yana-web/lib/skills.js` | test tiếng Việt "SSL certificate" giờ match đúng |
| 5 con số agent khác nhau ở 5 file (162/95/93/101/204) | README×4 ngôn ngữ, ARCHITECTURE.md, worker.js, agents-data.json | script `generate-stats.py --check` xác nhận khớp |
| `agents-data.json` chỉ 93/101 agent (thiếu nguyên `security-team`, `research`, `planner`) | site/docs agents-data.json | sinh lại đủ 101 bằng `generate-agents-data.py` |
| Không pin Rust version → lỗi `edition2024` khó hiểu | `rust-toolchain.toml` (mới) | build sạch trên toolchain đúng |
| `yana.md` trùng `name: yana` giữa 2 persona khác nhau | `core/agents/yana/yana.md` | đổi tên `yana-web-assistant` |
| CHANGELOG thiếu hẳn entry v0.43.0 | `CHANGELOG.md` | đã thêm |

### Đính chính quan trọng (bạn đã bắt đúng)

Ban đầu mình gọi 8162 entry lệch trong `.claude/config/skills-lock.json` là "ảo"
(ngụ ý bịa số liệu) — **sai**. Check lại `addedAt` timestamp gốc: 6583 entry
cùng ngày 2026-06-01, 1853 entry cùng ngày 2026-05-29 — rõ ràng một lượt quét
tự động thật, không phải số bịa. Đúng bản chất: **dữ liệu từng đúng lúc ghi,
lệch lúc đọc** vì nội dung sau đó bị dọn khỏi `.claude/skills/` mà lock file
không được prune theo. Đã sửa lại chữ trong `CHANGELOG.md` và hướng dẫn.

### Việc CHỈ BẠN làm được — CHƯA XÁC NHẬN ĐàLÀM

```bash
cargo login
cargo yank --version 1.3.0 -p yana-rt
```

`yana-rt` bị publish nhầm — bản `1.3.0` (dùng scheme version của crate)
publish TRƯỚC bản `0.42.1→0.43.0` (dùng scheme version của sản phẩm). Semver
coi `1.3.0 > 0.43.0`, nên **ai `cargo install yana-rt` bây giờ vẫn đang lấy
nhầm bản `1.3.0`** — mọi thứ vá trong `0.42.x`-`0.43.0` không tới tay họ.
Đây là việc còn treo lâu nhất trong toàn bộ audit — ưu tiên xử lý.

---

## 2. Vòng 2 — Đọc sâu code thật (không chỉ đếm/grep)

### Phạm vi đã đọc kỹ (có test/build xác nhận, không chỉ đọc mắt)

- `src/scanner/{mod,matchers,rules,files}.rs` — engine quét bảo mật
- `src/route.rs` — bộ phân loại task simple/complex/external
- `src/mission/mod.rs` — điều phối agent song song (691 dòng, đọc hết)
- `core/hooks/guard-destructive.sh`, `truth-gate-guard.sh` — đọc + test bằng tay
- `tools/yana-web/{server,auth,shared/crypto-store}.js` — app web thật
- `vendor/*` — kiểm tra license 8/8 thư mục
- Toàn bộ 1989 `SKILL.md` — quét cấu trúc (không phải đọc từng cái, dùng script)

### Vẫn CHƯA đọc (để không tự nhận "xong" khi chưa xong)

- Phần lớn `core/commands/` (42k dòng — chủ yếu prompt instruction, rủi ro thấp hơn code thực thi)
- `site/src/` (docs site, 1.8k dòng)
- `github-app/src/*.ts` (375 dòng — mới đếm, chưa đọc logic)
- Các module Rust còn lại: `graph/`, `vault/` (đã lướt), `hunt/`, `fix/`, `spec/`, `ci/`, `watch/`, `design/`

### Đã fix (Yana-AI-fixes-round2.zip)

| # | Bug | Mức độ | File | Test |
|---|---|---|---|---|
| 1 | `rm -rf`/`git push -f`/`git clean -f` bypass được qua flag viết kiểu khác (`--recursive --force`, `-r -f`, `-uf`, `-df`...) | 🔴 Cao nhất — đụng đúng lời hứa cốt lõi | `guard-destructive.sh` (bash + Rust `src/guard/mod.rs`) | 26 case bash + 24 case Rust, tất cả pass |
| 2 | Mission dispatcher không check 2 task chạy song song có `owns` đè nhau | 🟡 | `src/mission/mod.rs` | 8 test `owns_conflict` |
| 3 | `cmd_done` nhận evidence string bất kỳ, không verify | 🟡 | `src/mission/mod.rs` | verify path tồn tại trước khi accept |
| 4 | `yana-ai scan` tự báo sai version `"0.16.0"` hardcode | 🟢 | `src/scanner/mod.rs` | build sạch, dùng `env!("CARGO_PKG_VERSION")` |
| 5 | Test mã hoá API key (`crypto-store`) crash vì sai path, không chạy được từ lâu | 🟡 | `_test_crypto_store.js` | từ crash → 18/18 pass |
| 6 | `LOGIN_RATE` map không tự dọn IP hết hạn | 🟢 | `auth.js` | 28/28 test cũ vẫn xanh |

**Lưu ý về #1:** `blast_radius.rs` (module riêng, đo hậu quả thay vì match text
lệnh) đã tự che được phần lớn case `rm` — nhưng KHÔNG che `git push`/`git clean`
chút nào. Fix này không phải làm trùng việc, mà lấp đúng phần trống.

### Điểm tốt tìm thấy khi đọc sâu (để công bằng)

- `matchers.rs`, `truth-gate-guard.sh` — code có bằng chứng debug/fix thật, không phải AI generate qua loa
- `auth.js` — scrypt đúng chuẩn, timing-safe compare, cookie flags đúng
- 1989 skill quét toàn bộ: 0 thiếu field bắt buộc, 0 nội dung trùng lặp — lo ngại "thin/shallow" từ audit rất đầu không đúng ở quy mô lớn
- `vendor/` 8/8 thư mục license hợp lệ, tương thích Apache-2.0

---

## 3. Trạng thái test cuối cùng (sau cả 2 vòng fix)

```
Python:  663 passed, 1 skipped
JS:      114 passed  (auth 28 · classifier 14 · crypto-store 18 · memory 28 · missions 26)
Rust:    build sạch; logic-verified qua rustc trực tiếp (cargo test không chạy được
         trong sandbox mình dùng — Rust 1.75 từ apt, thiếu edition2024 mà vài
         dependency cần; Mac bạn có rustup thật nên chạy `cargo test` sẽ đầy đủ hơn)
```

---

## 4. Hướng phát triển tiếp — chưa làm, cần bạn quyết định

Không phải bug, là quyết định chiến lược:

1. **Vá xong core an toàn trước khi mở rộng thêm** — 5 ngày trước lúc audit đầu,
   dự án thêm Electron/GitHub App/Cloudflare Worker/3 cloud deploy trong lúc bug
   guard-destructive vẫn tồn tại. Đề xuất: tạm dừng bề mặt mới cho tới khi mảng
   an toàn ổn định hẳn.
2. **Semantic skill router** — công việc từ session trước (581 dòng Rust,
   eval harness) đã biến mất khỏi repo, chưa rõ bị bỏ hay thất lạc. Cần quyết
   định dứt điểm: làm tiếp hay bỏ hẳn khỏi roadmap.
3. **Wire `generate-stats.py --check` vào CI thật** — file đã có sẵn từ vòng 1,
   chưa được gắn vào `.github/workflows/`.
4. **Mission dispatcher** giờ đã chặn được xung đột `owns`, nhưng vẫn chưa có
   diff-based verify thật cho `cmd_done` (mới verify path tồn tại, chưa verify
   nội dung đúng phạm vi `owns`) — có thể làm sâu hơn nếu muốn.
5. Cân nhắc nghiêm túc: một người maintain nổi ngần này surface (CLI + web +
   desktop + mobile + GitHub App + Worker + docs site + 3 registry) có bền
   không, hay nên thu hẹp phạm vi.

---

## 5. Nếu bạn chỉ có 10 phút, làm đúng thứ tự này

```bash
# 1. Backup
git add -A && git commit -m "checkpoint before audit fixes"

# 2. Áp cả 2 gói
rsync -av ~/Downloads/Yana-AI-fixes/ .        --exclude 'HUONG_DAN_AP_DUNG.md'
rsync -av ~/Downloads/Yana-AI-fixes-round2/ . --exclude 'HUONG_DAN_ROUND2.md'

# 3. Việc khẩn nhất — không nằm trong file nào cả, chỉ bạn làm được
cargo login && cargo yank --version 1.3.0 -p yana-rt

# 4. Verify
python3 -m pytest tests/ -q
cargo test --lib
cd tools/yana-web && node _test_crypto_store.js && node _test_auth.js && cd ../..
python3 core/scripts/generate-stats.py --check

# 5. Commit
git add -A && git commit -m "fix: guard bypasses, mission owns-conflict, evidence verify, stats reconciliation"
git push
```
